#import "CWIWidget.h"
#import "KonyCWIEnvironment.h"
#import "MyProtocol.h"

@interface MyWidget : UIControl<CWIWidget>
{
    KonyCWIEnvironment *konyEnvironment;
    id <MyProtocol> buttonEventDelegate;
    UIButton *button0;
    UIButton *button1;
    UIButton *button2;
    UIButton *button3;
    UIButton *button4;
    NSMutableArray *buttonArray;
    UIView *mainView;
    UIButton *buttonTest;
    int rating;
    
}

@property (nonatomic, retain) KonyCWIEnvironment *konyEnvironment;
@property (nonatomic, retain) id <MyProtocol> buttonEventDelegate;
@property (nonatomic,strong)UIButton *button0;
@property (nonatomic,strong)UIButton *button1;
@property (nonatomic,strong)UIButton *button2;
@property (nonatomic,strong)UIButton *button3;
@property (nonatomic,strong)UIButton *button4;
@property (nonatomic,strong)NSMutableArray *buttonArray;
@property (nonatomic,strong)UIView *mainView;
@property (nonatomic,strong)UIButton *buttonTest;
@property int rating;
@end