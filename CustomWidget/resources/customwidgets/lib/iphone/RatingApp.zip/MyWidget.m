#import "MyWidget.h"
int flag;
@implementation MyWidget

@synthesize konyEnvironment,buttonEventDelegate,buttonArray,button0,button1,button2,button3,button4,buttonTest,mainView,rating;

-(id)init{
    
    NSLog(@"--------Entering into init-------------");
    
    self = [super init];
    if(self)
    {
        [self loadWidgets];
    }
    return self;
    
    NSLog(@"-----------Exiting init method---------");
}
-(void) loadWidgets{
    
    NSLog(@"-----------Inside loadWidgets method---------");
    buttonArray = [[NSMutableArray alloc]initWithObjects:button0,button1,button2,button3,button4,nil];
    button0 = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    button1 = [[UIButton alloc]initWithFrame:CGRectMake(50, 0, 50, 50)];
    button2 = [[UIButton alloc]initWithFrame:CGRectMake(100, 0, 50, 50)];
    button3 = [[UIButton alloc]initWithFrame:CGRectMake(150, 0, 50, 50)];
    button4 = [[UIButton alloc]initWithFrame:CGRectMake(200, 0, 50, 50)];
    [button0 setTag:0];
    [button1 setTag:1];
    [button2 setTag:2];
    [button3 setTag:3];
    [button4 setTag:4];
    buttonArray[0]=button0;
    buttonArray[1]=button1;
    buttonArray[2]=button2;
    buttonArray[3]=button3;
    buttonArray[4]=button4;
    [button0 setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    [button1 setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    [button2 setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    [button3 setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    [button4 setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    
    [button0 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button1 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button2 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button3 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button4 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:button0];
    [self addSubview:button1];
    [self addSubview:button2];
    [self addSubview:button3];
    [self addSubview:button4];
    
    
    NSLog(@"-----------Exiting loadWidgets method---------");
}
-(void) rateIt:(int)num{
    NSLog(@"In rateIt");
    int i;
    UIButton *button;
    if(num>0){
      num=num>5?5:num;
    }else{
        num=0;
    }
    
    for(i=0;i<num;i++)
    {
        button=buttonArray[i];
        [button setBackgroundImage:[UIImage imageNamed:@"full_star.png"] forState:(UIControlStateNormal)];
    }
    for(;i<5;i++){
        button=buttonArray[i];
        [button setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    }
}
-(void)buttonClicked:(UIButton *)sender  {
    int buttonIndex = sender.tag;
    NSLog(@"-----button clicked----------");
    UIButton *button;
    int i=0;
    for(;i<=buttonIndex;i++)
    {
        button=buttonArray[i];
        [button setBackgroundImage:[UIImage imageNamed:@"full_star.png"] forState:(UIControlStateNormal)];
    }
    for(;i<[buttonArray count];i++){
        button=buttonArray[i];
        [button setBackgroundImage:[UIImage imageNamed:@"empty_star.png"] forState:(UIControlStateNormal)];
    }
	[self.buttonEventDelegate  onSelection:(buttonIndex+1)];
}


- (id)initWithEventDelegate:(id) eventDelegate withKonyEnvironment:(id) env
{
    
    
    NSLog(@"Inside initWithEventDelegate Method");
    
    flag = 1;
    self = [self init];
    self.konyEnvironment = env;
    self.buttonEventDelegate = eventDelegate;
    return self;
    
    
    NSLog(@"-----------Exiting intiWithEventDelegate method---------");
}

- (void) modelUpdatedForProperty:(NSString*) propertyName  withOldValue:(id) oValue newValue:(id) nValue
{
    NSLog(@"-----------Inside modelUpdatedForProperty method---------");
    if([propertyName isEqualToString:@"rating"])
    {
        
        [self rateIt:[nValue integerValue]];
    }
    
    NSLog(@"-----------Exiting modelUpdatedForProperty method---------");
}

- (UIView*) getWidgetView
{
    NSLog(@"-----------Inside getWidgetView method---------");
    
    return self;
    
    NSLog(@"-----------Exiting getWidgetView method---------");
}

- (CGSize) getPreferredSizeForGivenSize: (CGSize) givenSize
{
    NSLog(@"-----------Inside getPreferredSizeForGivenSize method---------");
    
    return [UIScreen mainScreen].bounds.size;
    /*CGSize size=givenSize;
    size.height=200;
    return size;*/
    NSLog(@"-----------Exiting getPreferredSizeForGivenSize method---------");
}

- (void) setWidgetViewFrame: (CGRect) frame
{
    
    NSLog(@"-----------Inside setWidgetFrame method---------");
    frame.size.width=[UIScreen mainScreen].bounds.size.width;
    frame.size.height=[UIScreen mainScreen].bounds.size.height;
    self.frame = frame;
    NSLog(@"-----------Exiting setWidgetFrame method---------");
}



-(void)dealloc
{
    NSLog(@"-----------Inside dealloc method---------");
    
    [super dealloc];
    
    NSLog(@"-----------Exiting dealloc method---------");
}
@end