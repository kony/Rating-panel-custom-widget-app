#import <Foundation/Foundation.h>

@protocol MyProtocol <NSObject>
 -(void) onSelection:(int)num;
 -(void) setRating:(int) num;

@end
